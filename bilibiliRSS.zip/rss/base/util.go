package base

import "net/http"

var client = &http.Client{}
