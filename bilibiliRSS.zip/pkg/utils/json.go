package utils

import json "github.com/json-iterator/go"

var Json = json.ConfigCompatibleWithStandardLibrary
